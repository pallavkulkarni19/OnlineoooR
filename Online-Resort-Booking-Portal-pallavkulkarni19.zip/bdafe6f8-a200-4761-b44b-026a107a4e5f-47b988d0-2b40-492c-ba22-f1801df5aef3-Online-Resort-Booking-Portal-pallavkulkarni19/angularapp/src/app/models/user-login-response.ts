export class UserLoginResponse {
    userId:number
    userName:string
    userRole:string
    token:string
}
