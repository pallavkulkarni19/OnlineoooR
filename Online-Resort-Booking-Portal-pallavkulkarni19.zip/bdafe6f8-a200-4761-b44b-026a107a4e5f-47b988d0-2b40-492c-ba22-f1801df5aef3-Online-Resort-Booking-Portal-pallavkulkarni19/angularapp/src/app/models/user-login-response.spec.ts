import { UserLoginResponse } from './user-login-response';

describe('UserLoginResponse', () => {
  it('should create an instance', () => {
    expect(new UserLoginResponse()).toBeTruthy();
  });
});
