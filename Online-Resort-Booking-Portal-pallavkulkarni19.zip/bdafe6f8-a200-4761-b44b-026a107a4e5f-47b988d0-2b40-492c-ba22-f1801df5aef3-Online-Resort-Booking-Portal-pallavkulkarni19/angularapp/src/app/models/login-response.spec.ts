import { LoginResponse } from './login-response';

describe('LoginResponse', () => {
  it('should create an instance', () => {
    expect(new LoginResponse()).toBeTruthy();
  });
});
