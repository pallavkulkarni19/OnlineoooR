export interface User {
    UserId?: number;
    Email: string;
    Password: string;
    Username?: string;
    MobileNumber?: string;
    UserRole?: string;
}
