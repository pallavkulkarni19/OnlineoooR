export interface UserLoginModel {
    email:string;
    password:string;
}
