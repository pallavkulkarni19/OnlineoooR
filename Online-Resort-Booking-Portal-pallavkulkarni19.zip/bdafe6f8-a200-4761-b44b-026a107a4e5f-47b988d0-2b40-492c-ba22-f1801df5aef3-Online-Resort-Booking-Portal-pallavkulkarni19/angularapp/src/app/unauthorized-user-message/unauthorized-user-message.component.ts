import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unauthorized-user-message',
  templateUrl: './unauthorized-user-message.component.html',
  styleUrls: ['./unauthorized-user-message.component.css']
})
export class UnauthorizedUserMessageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
