import { Component, OnInit } from '@angular/core';
import { ResortService } from 'src/app/services/resort.service';
import { NgClass } from '@angular/common';
 
@Component({
  selector: 'app-view-resort',
  templateUrl: './view-resort.component.html',
  styleUrls: ['./view-resort.component.css']
})
export class ViewResortComponent implements OnInit {
 
 
  constructor(private resortservice : ResortService) { }
  resorts:any[]
 
  ngOnInit(): void {
    this.getAllResorts();
 
  }
  getAllResorts():void{
    this.resortservice.getAllResorts().subscribe(data =>{this.resorts = data;  console.log(data)})
  }

  formatPrice(price:number):string{
    return price.toLocaleString();
  }
 
}
 