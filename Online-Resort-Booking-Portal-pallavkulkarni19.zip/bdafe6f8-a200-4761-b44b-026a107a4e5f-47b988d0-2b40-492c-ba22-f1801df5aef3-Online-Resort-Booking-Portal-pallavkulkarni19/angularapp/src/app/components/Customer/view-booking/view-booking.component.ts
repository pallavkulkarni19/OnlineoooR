import { Component, OnInit } from '@angular/core';
import { BookingService } from 'src/app/services/booking.service';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-view-booking',
  templateUrl: './view-booking.component.html',
  styleUrls: ['./view-booking.component.css']
})
export class ViewBookingComponent implements OnInit {
  showConfirmDialog: boolean = false;
  bookings:any[]
  constructor(private service: BookingService,private router:Router,private authService:AuthService) { }

  ngOnInit(): void {
    this.displayBookings()
  }
 
  confirmDelete(booking:any):void{
    if(booking.status !=='Accepted'){
      this.deleteItem(booking.bookingId)
    }
    else{
      this.cancelDelete(booking);
    }
  }
  // confirmDelete(booking:any): void {
  //   if(booking.Status==='Accepted'){
  //     // booking.isDeleted=true
  //     alert('Booking Status - Accepted, cant delete');
  //     this.cancelDelete(booking)

  //   }
  //   else{
  //     // this.showConfirmDialog = true;
  //     // booking.isDeleted = true;
  //     this.deleteItem(booking.bookingId);
  //   }
  // }
 
  cancelDelete(booking:any): void {
    // booking.isDeleted=false;
    // this.showConfirmDialog = false;
    alert('Your Booking is already accepted, booking can not be deleted !');

  }
 
  deleteItem(bookingId: number): void {
    // Delete logic goes here
    this.service.deleteBooking(bookingId).subscribe(()=>{
      confirm("Are you sure, you want to delete booking!")
      console.log('Booking Deleted:'); 
      //window.location.href='/Cbookings'
      // this.router.navigate(['/Cbookings']);
      // this.bookings= this.bookings.filter(booking=>booking.id!==bookingId);
    
      this.displayBookings();
    });
    console.log('Item deleted');
    this.showConfirmDialog = false;
  }
 
  displayBookings():void{
    const userid=this.authService.getUserId()
    if(userid !=  null)
    var id = Number(userid)
    this.service.getBookingsByUserId(id).subscribe(data=>{this.bookings=data; console.log(data)});
  }
  
  formatPrice(price:number):string{
    return price.toLocaleString();
  }
 
 
}