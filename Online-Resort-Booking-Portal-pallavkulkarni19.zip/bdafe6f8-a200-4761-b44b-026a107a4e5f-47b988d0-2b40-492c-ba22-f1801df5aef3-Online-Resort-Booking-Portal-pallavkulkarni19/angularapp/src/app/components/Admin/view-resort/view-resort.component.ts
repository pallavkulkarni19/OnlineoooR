
import { Component, OnInit } from '@angular/core';
import { ResortService } from 'src/app/services/resort.service';

@Component({
  selector: 'app-view-resort',
  templateUrl: './view-resort.component.html',
  styleUrls: ['./view-resort.component.css']
})
export class ViewResortComponent implements OnInit {
  resorts: any[];

  originalResorts:any[]
  flag1: number = 0;
  tempid: number;
  temp:any



  constructor(private resortService: ResortService) { }

  ngOnInit(): void {
    this.getAllResorts();
  }

  getAllResorts(): void {
    this.resortService.getAllResorts().subscribe(data => {
      this.resorts = data.map(resort => ({ ...resort, isEditing: false }));
      console.log(data);
    });
  }

  editResort(resort: any): void {
    if (this.flag1 == 0) {
      this.originalResorts=JSON.parse(JSON.stringify(this.resorts));

      resort.isEditing = true;
      this.flag1 = 1; //disable edit button if once clicked

      // this.originalResorts=[...this.resorts];
    }
  }
  fetchId(id:number)
  {
    this.tempid=0;
  }

  // saveResort(resort: any, resortId: number): void {
  //   this.temp=[...this.originalResorts];
  //   this.resortService.updateResort(resortId, this.resorts).subscribe(
  //     success => {
  //       console.log('Update successful');
  //       this.flag1 = 0; // Enable condition of edit button
  //       resort.isEditing = false; // Exit edit mode
  //       this.getAllResorts(); // Refresh the data from the server
  //     },
  //     error => console.error('Update failed', error)
  //   );
  // }
saveResort(resort: any, resortId: number): void {
  resort.isEditing = false;
  this.flag1 = 0; // enable condition of edit button

  // Prepare the resort data to be sent to the backend
  const updatedResortData = {
    resortName: resort.resortName,
    description: resort.description,
    resortImageUrl: resort.resortImageUrl,
    resortAvailableStatus: resort.resortAvailableStatus,
    resortLocation: resort.resortLocation,
    capacity: resort.capacity,
    price: resort.price
  };

  this.resortService.updateResort(resortId, updatedResortData).subscribe(
    success => {
      console.log('Update successful');
      // Update the resorts array with the updated data
      const index = this.resorts.findIndex(r => r.id === resortId);
      if (index !== -1) {
        this.resorts[index] = { ...this.resorts[index], ...updatedResortData };
      }
    },
    error => console.error('Update failed', error)
  );
}

  

  cancelEdit(resort: any): void {
    resort.isEditing = false;
    this.flag1 = 0;
    this.resorts=[...this.originalResorts];
  }

  confirmDelete(resortId: number): void {
    if (confirm('Are you sure you want to delete this resort?')) {
      this.resortService.deleteResort(resortId).subscribe(
        success => {
          console.log('Deletion successful');
          this.getAllResorts(); // Reload the list after deletion
        },
        error => console.error('Deletion failed', error)
      );
    }
  }

  onFileChanged(event: any, resort: any): void {
    const selectedFile = event.target.files[0];
    const reader = new FileReader();
    reader.readAsDataURL(selectedFile);
    reader.onload = () => {
      resort.base64String = reader.result as string;
    };
  }


  formatPrice(price:number):string{
    return price.toLocaleString();
  }
}
