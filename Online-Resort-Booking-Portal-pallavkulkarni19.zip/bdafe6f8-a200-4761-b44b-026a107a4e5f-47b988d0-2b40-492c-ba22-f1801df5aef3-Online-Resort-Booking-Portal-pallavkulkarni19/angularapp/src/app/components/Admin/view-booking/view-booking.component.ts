import { Component, OnInit } from '@angular/core';
import { NgModel } from '@angular/forms';
import { BookingService } from 'src/app/services/booking.service';

@Component({
  selector: 'app-view-booking',
  templateUrl: './view-booking.component.html',
  styleUrls: ['./view-booking.component.css']
})
export class ViewBookingComponent implements OnInit {
  bookings: any[]

  constructor(private bookingService: BookingService) { }

  ngOnInit(): void {
    this.getAllBookings();
  }

  simplealert() {
  }

  confirm() {

  }

  getAllBookings(): void {
    this.bookingService.getAllBookings().subscribe(data => { this.bookings = data, console.log(data) })
  }



  formatPrice(price: number): string {
    return price.toLocaleString();
  }

  acceptd: string = "Accepted"

  acceptBooking(bookingId: number): void {
    this.updateBookingStatus(bookingId, this.acceptd);
    // alert("")
  }


  rejectd: string = "Rejected"

  rejectBooking(bookingId: number): void {
    this.updateBookingStatus(bookingId, this.rejectd);
  }

  private updateBookingStatus(bookingId: number, newStatus: string): void {
    // this.bookings.status=newStatus;
    // const updatedBooking={Status:newStatus};
    this.bookingService.updateBooking(bookingId, newStatus).subscribe(
      () => {
        console.log(`Booking ${newStatus}:`, bookingId, newStatus);
        this.getAllBookings();
      },
      (error) => {
        console.error(`Error ${newStatus.toLowerCase()} booking:`, error);
      }
    );
  }


}
