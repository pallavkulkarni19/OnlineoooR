import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ResortService {

  private baseUrl = "https://8080-ccafdaaebbabdaaababefdcaeaaeedbdbcbafdfaef.premiumproject.examly.io/api";

 
  constructor(private http: HttpClient, private router: Router){}
  getAllResorts(): Observable<any> {
    return this.http.get(`${this.baseUrl}/resort`);
  }

  createResort(resort: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/resort`, resort);
  }

  updateResort(resortId: number, resort: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/resort/${resortId}?id=${resortId}`, resort);
  }

  deleteResort(resortId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/resort/${resortId}?id=${resortId}`);
  }

  getResortById(resortId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/resort/${resortId}?id=${resortId}`);
  }

   getAllReviews(): Observable<any> {
    return this.http.get(`${this.baseUrl}/review`);
  }

  createReview(review: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/review`, review);
  }

  getReviewsByUserId(userId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/review/${userId}`);
  }
}