import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  private baseUrl = "https://8080-ccafdaaebbabdaaababefdcaeaaeedbdbcbafdfaef.premiumproject.examly.io/api";

  constructor(private http: HttpClient) { }

  getAllBookings(): Observable<any> {
    return this.http.get(`${this.baseUrl}/booking`);
  }

  createBooking(booking: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/booking`, booking);
  }

  deleteBooking(bookingId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/booking/${bookingId}?id=${bookingId}`);
  }

  updateBooking(bookingId: number, newStatus: any): Observable<any> {
    console.log("newStatus=" + newStatus)
    return this.http.put(`${this.baseUrl}/booking/${bookingId}/${newStatus}`,bookingId );
  }


  getBookingById(bookingId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/booking/${bookingId}?id=${bookingId}`);
  }

  getBookingsByUserId(userId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/booking/user/${userId}`);
  }
}