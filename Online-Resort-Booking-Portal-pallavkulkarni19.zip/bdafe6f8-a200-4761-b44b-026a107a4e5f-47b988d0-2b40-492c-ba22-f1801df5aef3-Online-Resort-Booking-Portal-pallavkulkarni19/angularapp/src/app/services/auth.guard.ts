import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { AuthService } from './auth.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  unauthorized: boolean = false; // Add unauthorized variable

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const expectedRole = route.data.roles as string; // Get the required role from route data

    if (!this.authService.isLoggedIn()) {
      this.unauthorized = true;
      this.router.navigate(['/login']);
      return false;
    }

    if (this.unauthorized) { // Check if unauthorized
      this.unauthorized = false;
      this.router.navigate(['/login']);
      return false;
    }
    
    // Reset unauthorized to false when user is logged in
    this.unauthorized = false;

    const currentUserRole = this.authService.getUserRole();
    if (currentUserRole !== expectedRole) {
      this.showUnauthorizedAlert(); // Show unauthorized alert
      return false;
    }

    return true;
  }

  private showUnauthorizedAlert() {
    alert('You are not authorized to access this service, login again!'); // Show alert message
    // Optionally, you can navigate the user to a specific page instead of showing an alert
    localStorage.removeItem('user');
    this.router.navigate(['/']); // Redirect to home page or another page
    // if(c=='Admin')
    // {this.router.navigate(['/Ahome']);
    // return true;}
    // else if(c=='Customer'){this.router.navigate(['/Ahome']);
    // return true;}
  }
}
