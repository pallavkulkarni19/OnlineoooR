using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;

namespace dotnetapp.Models
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(){}
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options){}
        public DbSet<User> Users{get;set;}
        public DbSet<Booking> Bookings{get;set;}
        public DbSet<Resort> Resorts{get;set;}
        public DbSet<Review> Reviews{get;set;}
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if(!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("User ID=sa; password=examlyMssql@123; server=localhost;Database=TestDb; trusted_connection=false; Persist Security Info=False; Encrypt=False");
            }
        }
    }
}