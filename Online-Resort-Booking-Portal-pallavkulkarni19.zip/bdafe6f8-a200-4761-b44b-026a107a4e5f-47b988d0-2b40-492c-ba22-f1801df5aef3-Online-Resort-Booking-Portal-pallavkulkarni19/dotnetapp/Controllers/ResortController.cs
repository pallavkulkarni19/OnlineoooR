using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using dotnetapp.Models;
using dotnetapp.Services;

namespace dotnetapp.Controllers
{   
    
    [Route("api/")]
    [ApiController]
    public class ResortController : ControllerBase
    {
        private readonly IResortService _resortService;

        public ResortController(IResortService resortService)
        {
            _resortService = resortService;
        }
        [Authorize]
        [HttpGet("resort")]
        
        public async Task<ActionResult<List<Resort>>> GetAllResorts()
        {
            try
            {
                var resorts = await _resortService.GetAllResortsAsync();
                return Ok(resorts);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("resort")]
        [Authorize(Roles="Admin")]
        public async Task<ActionResult> AddResort([FromBody] Resort resort)
        {
            try
            {
                await _resortService.AddResortAsync(resort);
                return Created("Successfully added",resort);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut("resort/{id}")]
        [Authorize(Roles="Admin")]
        public async Task<ActionResult> UpdateResort(long id, [FromBody] Resort resort)
        {
            try
            {
                await _resortService.UpdateResortAsync(id, resort);
                // return Created("Created",resort);
                return Ok();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpDelete("resort/{id}")]
        [Authorize(Roles="Admin")]
        public async Task<ActionResult> DeleteResort(long id)
        {
            try
            {
                await _resortService.DeleteResortAsync(id);
                return Ok();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet("resort/{id}")]
       
        public async Task<ActionResult<Resort>> GetResortById(long id)
        {
            try
            {
                var resort = await _resortService.GetResortByIdAsync(id);
                if (resort == null)
                {
                    return NotFound();
                }
                return Ok(resort);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}